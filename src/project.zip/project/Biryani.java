package project;

public class Biryani extends Food {

	protected String meatType; //Beef, chicken and mutton
	protected String SpiceLevel; //medium, high etc
	protected String Size;
	protected boolean aloo;
	
	public Biryani(double m, String a, String b, String c, boolean d) {
		super(m);
		meatType = a;
		SpiceLevel = b; 
		Size = c;
		aloo = d;
	}
	
	public void setMeat(String a) {
		meatType = a;
	}
	public String getMeat() {
		return meatType;
	}
	
	public void setSpice(String b) {
		SpiceLevel = b;
	}
	public String getSpice() {
		return SpiceLevel;
	}
	
	public void setSize(String c) {
		Size = c;
	}
	public String getSize() {
		return Size;
	}
	public void setAloo(boolean d) {
		aloo = d;
	}
	public boolean getAloo() {
		return aloo;
	}
	
	public boolean availblityOfFood() {
		return true;
	}
	
	
}



