package project;

public class Karhai {

	protected String meatType; //Beef, chicken and mutton
	protected String type; //white, green or standard
	protected String quantity; //half, full
	
	public Karhai(String a, String b, String c) {
		meatType = a;
		type = b; 
		quantity = c;
		
	}
	
	public void setMeat(String a) {
		meatType = a;
	}
	public String getMeat() {
		return meatType;
	}
	
	public void setType(String b) {
		type = b;
	}
	public String getType() {
		return type;
	}
	
	public void setQuantity(String c) {
		quantity = c;
	}
	public String getQuantity() {
		return quantity;
	}
	
	
	public boolean availblityOfFood() {
		return true;
	}
	
	








}
