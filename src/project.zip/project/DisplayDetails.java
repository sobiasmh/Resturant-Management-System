package project;

public interface DisplayDetails {

}
