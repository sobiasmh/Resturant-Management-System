package project;

public interface DisplayDetails {
	public void displayDetails();

}
